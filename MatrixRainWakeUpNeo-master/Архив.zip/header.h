#ifndef HEADER_H
#define HEADER_H

#include <ncurses.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

static void mx_intro();

#endif


